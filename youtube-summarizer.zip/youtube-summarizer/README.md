# Resumidor de Videos de YouTube con IA

Aplicación full-stack que permite pegar la URL de un video de YouTube y obtener:

- 📝 **Resumen** generado por IA (en viñetas o párrafo, con nivel de detalle ajustable).
- 🌍 **Soporte multilingüe**: el resumen se genera en el idioma que elijas, aunque el video esté en otro.
- 🖼️ **Metadatos del video**: título, miniatura, canal y duración.
- 🧠 **Mapa mental** jerárquico del contenido.
- 💬 **Chat**: pregunta cosas puntuales sobre el video y la IA responde basándose en la transcripción.

## Arquitectura

```
youtube-summarizer/
├── backend/      FastAPI (Python) — extracción de YouTube + orquestación de IA
└── frontend/     React 18 + Vite + Tailwind CSS
```

- **Backend**: expone una API REST. Usa `yt-dlp` para metadatos y `youtube-transcript-api`
  para la transcripción (con fallback automático a subtítulos auto-generados o traducidos
  si el idioma pedido no existe de forma nativa). La generación de texto se delega a un
  proveedor de IA intercambiable: **Gemini**, **OpenAI** o **Anthropic (Claude)** — se elige
  con una variable de entorno, sin tocar código.
- **Frontend**: SPA en React que consume la API y muestra resumen, mapa mental y chat.
- El **chat** usa un "RAG" simple: la transcripción se divide en fragmentos y, para cada
  pregunta, se seleccionan los fragmentos más relevantes con TF-IDF (`scikit-learn`) antes
  de mandarlos al modelo de IA — así no hace falta una base de datos vectorial para un solo
  video.

## Requisitos previos

- Python 3.10 o superior
- Node.js 18 o superior
- Una clave de API de **al menos uno** de estos proveedores de IA:
  - [Google AI Studio (Gemini)](https://aistudio.google.com/app/apikey) — tiene nivel gratuito
  - [OpenAI](https://platform.openai.com/api-keys)
  - [Anthropic (Claude)](https://console.anthropic.com/settings/keys)

## 1. Configurar el backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # En Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
```

Edita `backend/.env` y completa:

```env
AI_PROVIDER=gemini              # gemini | openai | anthropic
GEMINI_API_KEY=tu_clave_aqui    # (o OPENAI_API_KEY / ANTHROPIC_API_KEY según el proveedor)
```

Levanta el servidor:

```bash
uvicorn app.main:app --reload --port 8000
```

La API queda disponible en `http://localhost:8000`. Puedes ver la documentación interactiva
(Swagger) en `http://localhost:8000/docs`.

## 2. Configurar el frontend

En otra terminal:

```bash
cd frontend
npm install
cp .env.example .env   # solo si tu backend NO corre en localhost:8000
npm run dev
```

Abre `http://localhost:5173` en tu navegador.

## 3. Probar la aplicación

1. Pega una URL de YouTube, por ejemplo: `https://www.youtube.com/watch?v=dQw4w9WgXcQ`
2. Elige idioma, formato (viñetas/párrafo) y nivel de detalle.
3. Pulsa **"Resumir video"**.
4. Cambia entre las pestañas **Resumen**, **Mapa mental** y **Chat**.

> ⚠️ El resumen solo funciona con videos que tengan subtítulos (manuales o automáticos)
> habilitados en YouTube. Si un video no tiene subtítulos, la app lo indicará con un
> mensaje claro en vez de fallar silenciosamente.

## Endpoints de la API

| Método | Ruta                  | Descripción                                          |
|--------|------------------------|-------------------------------------------------------|
| POST   | `/api/video/info`       | Metadatos del video (título, miniatura, duración)    |
| POST   | `/api/video/summarize`  | Pipeline completo: metadatos + transcripción + resumen |
| POST   | `/api/video/mindmap`    | Mapa mental jerárquico del contenido                 |
| POST   | `/api/video/chat`       | Preguntas y respuestas sobre el video (RAG)          |
| GET    | `/api/languages`        | Lista de idiomas sugeridos para el selector          |
| GET    | `/api/health`           | Health check                                         |

Todos los `POST` reciben JSON con al menos `{ "url": "...", "language": "es" }`.
Ver `backend/app/schemas.py` para el detalle exacto de cada payload.

## Cambiar de proveedor de IA

Todo el código de IA está abstraído en `backend/app/services/ai_service.py` detrás de la
clase `AIProvider`. Para cambiar de proveedor solo se necesita editar `.env`:

```env
AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
```

No es necesario tocar ningún otro archivo.

## Solución de problemas comunes

- **"No se pudo conectar con el servidor"**: asegúrate de que el backend esté corriendo
  (`uvicorn app.main:app --reload --port 8000`) y que `VITE_API_BASE_URL` apunte a la URL
  correcta.
- **"Este video no tiene subtítulos/transcripción disponibles"**: prueba con otro video.
  No todos los videos de YouTube tienen subtítulos.
- **Error 502 / "Error llamando a Gemini/OpenAI/Anthropic"**: revisa que la clave de API en
  `.env` sea correcta y tenga saldo/cuota disponible.
- **CORS error en el navegador**: añade el origen de tu frontend a `CORS_ORIGINS` en
  `backend/.env` (separado por comas).

## Funcionalidades opcionales implementadas

- ✅ Mapa mental jerárquico (estructurado como JSON por la IA y renderizado como árbol).
- ✅ Chat/QA sobre el contenido del video con recuperación de fragmentos relevantes (TF-IDF).

## Limitaciones conocidas / próximos pasos

- La caché de transcripciones/metadatos es en memoria (válida para un solo proceso). En
  producción con varias réplicas, sustituir por Redis.
- `youtube-transcript-api` depende de que YouTube no cambie su API interna de subtítulos;
  si deja de funcionar, revisa si hay una versión más nueva de la librería.
- Para videos muy largos, la transcripción se trunca a `MAX_TRANSCRIPT_CHARS` (configurable
  en `backend/app/config.py`) antes de mandarla al modelo de IA, por límites de contexto.

## Despliegue (opcional)

- **Backend**: cualquier servicio que soporte Python/ASGI (Railway, Render, Fly.io, un VPS
  con `uvicorn`/`gunicorn` detrás de Nginx). Recuerda configurar las variables de entorno
  del `.env` en el panel del proveedor, nunca subir el `.env` al repositorio.
- **Frontend**: Vercel o Netlify funcionan de forma automática con `npm run build` (genera
  la carpeta `dist/`). Configura `VITE_API_BASE_URL` apuntando a la URL pública del backend.

## Licencia

Proyecto de ejemplo educativo. Úsalo y modifícalo libremente.
