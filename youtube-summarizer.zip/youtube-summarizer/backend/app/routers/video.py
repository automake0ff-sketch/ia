"""Endpoints relacionados con un video: metadatos, resumen y mapa mental."""
from fastapi import APIRouter

from app.schemas import (
    MindMapRequest,
    MindMapResponse,
    SummarizeRequest,
    SummaryResponse,
    VideoInfo,
    VideoURLRequest,
)
from app.services import ai_service, youtube_service

router = APIRouter(prefix="/api/video", tags=["video"])


def _build_video_info(video_id: str) -> VideoInfo:
    metadata = youtube_service.get_video_metadata(video_id)
    return VideoInfo(
        video_id=metadata.video_id,
        title=metadata.title,
        channel=metadata.channel,
        thumbnail=metadata.thumbnail,
        duration_seconds=metadata.duration_seconds,
    )


@router.post("/info", response_model=VideoInfo)
def get_video_info(payload: VideoURLRequest) -> VideoInfo:
    """Devuelve título, miniatura, canal y duración de un video (sin generar resumen)."""
    video_id = youtube_service.extract_video_id(payload.url)
    info = _build_video_info(video_id)

    # Adjuntamos qué idiomas de subtítulos existen, útil para el selector del frontend
    try:
        transcript = youtube_service.get_transcript(video_id, payload.language)
        info.available_caption_languages = transcript.available_languages
    except Exception:  # noqa: BLE001 - si falla, simplemente no mostramos idiomas disponibles
        pass

    return info


@router.post("/summarize", response_model=SummaryResponse)
def summarize_video(payload: SummarizeRequest) -> SummaryResponse:
    """Pipeline completo: metadatos + transcripción + resumen generado por IA."""
    video_id = youtube_service.extract_video_id(payload.url)
    video_info = _build_video_info(video_id)
    transcript = youtube_service.get_transcript(video_id, payload.language)

    summary, key_points = ai_service.summarize_transcript(
        transcript_text=transcript.full_text,
        language=payload.language,
        output_format=payload.format,
        length=payload.length,
    )

    video_info.available_caption_languages = transcript.available_languages

    return SummaryResponse(
        video=video_info,
        language=transcript.language_code,
        format=payload.format,
        summary=summary,
        key_points=key_points,
        transcript_source=transcript.source,
    )


@router.post("/mindmap", response_model=MindMapResponse)
def mindmap_video(payload: MindMapRequest) -> MindMapResponse:
    """Genera un mapa mental jerárquico del contenido del video."""
    video_id = youtube_service.extract_video_id(payload.url)
    video_info = _build_video_info(video_id)
    transcript = youtube_service.get_transcript(video_id, payload.language)

    mindmap_data = ai_service.generate_mindmap(
        transcript_text=transcript.full_text,
        language=payload.language,
        video_title=video_info.title,
    )

    return MindMapResponse(
        video=video_info,
        language=transcript.language_code,
        mindmap=mindmap_data,
    )
