"""Endpoint de chat: preguntas y respuestas sobre el contenido de un video."""
from fastapi import APIRouter

from app.schemas import ChatRequest, ChatResponse, VideoInfo
from app.services import ai_service, qa_service, youtube_service

router = APIRouter(prefix="/api/video", tags=["chat"])


@router.post("/chat", response_model=ChatResponse)
def chat_with_video(payload: ChatRequest) -> ChatResponse:
    """
    Responde una pregunta puntual sobre el video usando RAG simple:
      1. Obtiene la transcripción completa (cacheada).
      2. La divide en fragmentos.
      3. Recupera los fragmentos más relevantes para la pregunta (TF-IDF).
      4. Le pide al modelo de IA que responda basándose solo en esos fragmentos.
    """
    video_id = youtube_service.extract_video_id(payload.url)
    metadata = youtube_service.get_video_metadata(video_id)
    transcript = youtube_service.get_transcript(video_id, payload.language)

    chunks = youtube_service.chunk_text(transcript.full_text)
    relevant_chunks = qa_service.retrieve_relevant_chunks(chunks, payload.question)

    answer = ai_service.answer_question_with_context(
        question=payload.question,
        context_chunks=relevant_chunks,
        language=payload.language,
    )

    video_info = VideoInfo(
        video_id=metadata.video_id,
        title=metadata.title,
        channel=metadata.channel,
        thumbnail=metadata.thumbnail,
        duration_seconds=metadata.duration_seconds,
        available_caption_languages=transcript.available_languages,
    )

    return ChatResponse(
        video=video_info,
        question=payload.question,
        answer=answer,
        used_context=relevant_chunks,
    )
