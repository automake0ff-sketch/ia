"""Excepciones personalizadas con mensajes claros para el usuario final."""


class AppError(Exception):
    """Excepción base. status_code se usa para mapear a HTTPException en main.py"""

    status_code: int = 400
    error_code: str = "app_error"

    def __init__(self, message: str):
        self.message = message
        super().__init__(message)


class InvalidYouTubeURLError(AppError):
    status_code = 422
    error_code = "invalid_url"


class VideoUnavailableError(AppError):
    status_code = 404
    error_code = "video_unavailable"


class TranscriptNotAvailableError(AppError):
    status_code = 422
    error_code = "transcript_not_available"


class AIProviderError(AppError):
    status_code = 502
    error_code = "ai_provider_error"


class AIProviderNotConfiguredError(AppError):
    status_code = 500
    error_code = "ai_provider_not_configured"
