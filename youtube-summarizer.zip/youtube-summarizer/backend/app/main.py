"""
Punto de entrada de la aplicación FastAPI.

Ejecutar en desarrollo con:
    uvicorn app.main:app --reload --port 8000
"""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.exceptions import AppError
from app.routers import chat, video

settings = get_settings()

app = FastAPI(
    title=settings.APP_NAME,
    description="API para resumir videos de YouTube con IA: resúmenes, mapas mentales y chat sobre el contenido.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(AppError)
async def app_error_handler(request: Request, exc: AppError) -> JSONResponse:
    """Convierte nuestras excepciones de dominio en respuestas JSON consistentes."""
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.message, "error_code": exc.error_code},
    )


app.include_router(video.router)
app.include_router(chat.router)


@app.get("/", tags=["health"])
def root():
    return {"status": "ok", "app": settings.APP_NAME}


@app.get("/api/health", tags=["health"])
def health_check():
    return {"status": "ok", "ai_provider": settings.AI_PROVIDER}


@app.get("/api/languages", tags=["meta"])
def supported_languages():
    """Lista curada de idiomas sugeridos para el selector del frontend.
    El usuario también puede escribir cualquier código ISO soportado por el modelo de IA."""
    return [
        {"code": "es", "label": "Español"},
        {"code": "en", "label": "English"},
        {"code": "pt", "label": "Português"},
        {"code": "fr", "label": "Français"},
        {"code": "de", "label": "Deutsch"},
        {"code": "it", "label": "Italiano"},
        {"code": "ja", "label": "日本語"},
        {"code": "zh", "label": "中文"},
        {"code": "ar", "label": "العربية"},
        {"code": "ru", "label": "Русский"},
    ]
