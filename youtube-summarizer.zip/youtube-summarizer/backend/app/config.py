"""
Configuración centralizada de la aplicación.

Todas las claves API y parámetros sensibles se leen desde variables de entorno
(ver .env.example). Nunca se deben hardcodear claves en el código fuente.
"""
from functools import lru_cache
from typing import List, Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Entorno
    APP_ENV: str = "development"
    APP_NAME: str = "YouTube Video Summarizer AI"

    # CORS - lista separada por comas en .env, ej: "http://localhost:5173,https://miapp.com"
    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173"

    # Proveedor de IA activo: "gemini" | "openai" | "anthropic"
    AI_PROVIDER: Literal["gemini", "openai", "anthropic"] = "gemini"

    # Claves y modelos por proveedor
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-2.0-flash"

    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o-mini"

    ANTHROPIC_API_KEY: str = ""
    ANTHROPIC_MODEL: str = "claude-sonnet-4-6"

    # Límites de la aplicación
    MAX_TRANSCRIPT_CHARS: int = 120_000  # recorte de seguridad antes de mandar al LLM
    TRANSCRIPT_CACHE_TTL_SECONDS: int = 3600  # 1 hora de caché en memoria
    CHAT_TOP_K_CHUNKS: int = 4
    CHUNK_SIZE_WORDS: int = 180

    @property
    def cors_origins_list(self) -> List[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    """Devuelve una instancia cacheada de Settings (se lee .env una sola vez)."""
    return Settings()
