"""
Esquemas Pydantic usados para validar requests y formar responses de la API.
"""
from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------

class VideoURLRequest(BaseModel):
    url: str = Field(..., description="URL completa del video de YouTube")
    language: str = Field("es", description="Código de idioma ISO (es, en, fr, pt, de, ja, ...)")

    @field_validator("url")
    @classmethod
    def url_must_not_be_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("La URL no puede estar vacía")
        return v.strip()


class SummarizeRequest(VideoURLRequest):
    format: Literal["paragraph", "bullets"] = Field(
        "bullets", description="Formato del resumen: párrafo continuo o viñetas"
    )
    length: Literal["short", "medium", "long"] = Field(
        "medium", description="Nivel de detalle del resumen"
    )


class MindMapRequest(VideoURLRequest):
    pass


class ChatRequest(VideoURLRequest):
    question: str = Field(..., min_length=2, description="Pregunta del usuario sobre el video")


# ---------------------------------------------------------------------------
# Responses
# ---------------------------------------------------------------------------

class VideoInfo(BaseModel):
    video_id: str
    title: str
    channel: Optional[str] = None
    thumbnail: Optional[str] = None
    duration_seconds: Optional[int] = None
    available_caption_languages: List[str] = []


class SummaryResponse(BaseModel):
    video: VideoInfo
    language: str
    format: Literal["paragraph", "bullets"]
    summary: str
    key_points: List[str] = []
    transcript_source: Literal["manual", "auto_generated", "translated"]


class MindMapNode(BaseModel):
    title: str
    children: List["MindMapNode"] = []


MindMapNode.model_rebuild()


class MindMapResponse(BaseModel):
    video: VideoInfo
    language: str
    mindmap: MindMapNode


class ChatResponse(BaseModel):
    video: VideoInfo
    question: str
    answer: str
    used_context: List[str] = Field(
        default_factory=list, description="Fragmentos de transcripción usados para responder"
    )


class ErrorResponse(BaseModel):
    detail: str
    error_code: str
