"""
Servicio de IA: abstrae el proveedor (Gemini / OpenAI / Anthropic) detrás de
una interfaz común, y construye los prompts para cada funcionalidad:
  - Resumen del video (párrafo o viñetas, en el idioma elegido).
  - Mapa mental jerárquico (JSON estructurado).
  - Respuesta a preguntas sobre el video (RAG simple sobre fragmentos).

Cambiar de proveedor es tan simple como cambiar AI_PROVIDER en el .env.
"""
from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from functools import lru_cache
from typing import List, Tuple

from app.config import get_settings
from app.exceptions import AIProviderError, AIProviderNotConfiguredError

settings = get_settings()


# ---------------------------------------------------------------------------
# Interfaz común + implementaciones por proveedor
# ---------------------------------------------------------------------------
class AIProvider(ABC):
    @abstractmethod
    def generate(self, system_prompt: str, user_prompt: str, max_tokens: int = 1500) -> str:
        """Devuelve la respuesta de texto cruda del modelo."""
        raise NotImplementedError


class GeminiProvider(AIProvider):
    def __init__(self, api_key: str, model_name: str):
        import google.generativeai as genai

        genai.configure(api_key=api_key)
        self._genai = genai
        self.model_name = model_name

    def generate(self, system_prompt: str, user_prompt: str, max_tokens: int = 1500) -> str:
        try:
            model = self._genai.GenerativeModel(self.model_name, system_instruction=system_prompt)
            response = model.generate_content(
                user_prompt,
                generation_config={"temperature": 0.3, "max_output_tokens": max_tokens},
            )
            return response.text or ""
        except Exception as exc:  # noqa: BLE001
            raise AIProviderError(f"Error llamando a Gemini: {exc}") from exc


class OpenAIProvider(AIProvider):
    def __init__(self, api_key: str, model_name: str):
        from openai import OpenAI

        self.client = OpenAI(api_key=api_key)
        self.model_name = model_name

    def generate(self, system_prompt: str, user_prompt: str, max_tokens: int = 1500) -> str:
        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.3,
                max_tokens=max_tokens,
            )
            return response.choices[0].message.content or ""
        except Exception as exc:  # noqa: BLE001
            raise AIProviderError(f"Error llamando a OpenAI: {exc}") from exc


class AnthropicProvider(AIProvider):
    def __init__(self, api_key: str, model_name: str):
        import anthropic

        self.client = anthropic.Anthropic(api_key=api_key)
        self.model_name = model_name

    def generate(self, system_prompt: str, user_prompt: str, max_tokens: int = 1500) -> str:
        try:
            response = self.client.messages.create(
                model=self.model_name,
                max_tokens=max_tokens,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )
            return "".join(block.text for block in response.content if block.type == "text")
        except Exception as exc:  # noqa: BLE001
            raise AIProviderError(f"Error llamando a Anthropic: {exc}") from exc


@lru_cache
def get_ai_provider() -> AIProvider:
    provider_name = settings.AI_PROVIDER

    if provider_name == "gemini":
        if not settings.GEMINI_API_KEY:
            raise AIProviderNotConfiguredError(
                "AI_PROVIDER=gemini pero falta GEMINI_API_KEY en el archivo .env"
            )
        return GeminiProvider(settings.GEMINI_API_KEY, settings.GEMINI_MODEL)

    if provider_name == "openai":
        if not settings.OPENAI_API_KEY:
            raise AIProviderNotConfiguredError(
                "AI_PROVIDER=openai pero falta OPENAI_API_KEY en el archivo .env"
            )
        return OpenAIProvider(settings.OPENAI_API_KEY, settings.OPENAI_MODEL)

    if provider_name == "anthropic":
        if not settings.ANTHROPIC_API_KEY:
            raise AIProviderNotConfiguredError(
                "AI_PROVIDER=anthropic pero falta ANTHROPIC_API_KEY en el archivo .env"
            )
        return AnthropicProvider(settings.ANTHROPIC_API_KEY, settings.ANTHROPIC_MODEL)

    raise AIProviderNotConfiguredError(f"Proveedor de IA desconocido: {provider_name}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _safe_json_parse(raw_text: str) -> dict:
    """Extrae y parsea JSON de la respuesta del modelo, tolerando fences ```json y texto extra."""
    cleaned = raw_text.strip()
    cleaned = re.sub(r"^```(json)?", "", cleaned.strip(), flags=re.IGNORECASE).strip()
    cleaned = re.sub(r"```$", "", cleaned.strip()).strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Último recurso: tomar el primer bloque {...} balanceado del texto
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(cleaned[start : end + 1])
        except json.JSONDecodeError as exc:
            raise AIProviderError(
                f"El modelo devolvió una respuesta que no se pudo interpretar como JSON: {exc}"
            ) from exc

    raise AIProviderError("El modelo no devolvió un JSON válido.")


def _truncate(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n[... transcripción truncada por longitud ...]"


# ---------------------------------------------------------------------------
# Funcionalidad 1: Resumen
# ---------------------------------------------------------------------------
_LENGTH_GUIDANCE = {
    "short": "Muy breve: 80-130 palabras en total.",
    "medium": "Moderado: 180-280 palabras en total.",
    "long": "Detallado: 350-550 palabras en total.",
}


def summarize_transcript(
    transcript_text: str, language: str, output_format: str, length: str = "medium"
) -> Tuple[str, List[str]]:
    provider = get_ai_provider()
    transcript_text = _truncate(transcript_text, settings.MAX_TRANSCRIPT_CHARS)

    format_instruction = (
        "Devuelve el resumen como una lista de viñetas claras (usa '- ' al inicio de cada una), "
        "cada viñeta debe ser una idea autocontenida."
        if output_format == "bullets"
        else "Devuelve el resumen como 1 a 3 párrafos continuos y bien hilados, sin viñetas."
    )

    system_prompt = (
        "Eres un asistente experto en resumir el contenido de videos de YouTube a partir de su "
        "transcripción. Eres preciso, fiel al contenido original, evitas inventar información que "
        "no esté en la transcripción, y escribes de forma clara y directa."
    )

    user_prompt = f"""Idioma de salida obligatorio: {language}

Nivel de detalle: {_LENGTH_GUIDANCE.get(length, _LENGTH_GUIDANCE["medium"])}

Formato del campo "summary": {format_instruction}

Además del resumen, extrae entre 3 y 6 "key_points" (puntos clave), cada uno una frase corta
(máximo 15 palabras) que capture una idea central distinta del video.

Responde ÚNICAMENTE con un JSON válido (sin texto adicional, sin markdown) con esta forma exacta:
{{"summary": "...", "key_points": ["...", "..."]}}

Transcripción del video:
\"\"\"
{transcript_text}
\"\"\"
"""

    raw = provider.generate(system_prompt, user_prompt, max_tokens=2000)
    data = _safe_json_parse(raw)

    summary = str(data.get("summary", "")).strip()
    key_points = [str(p).strip() for p in data.get("key_points", []) if str(p).strip()]

    if not summary:
        raise AIProviderError("El modelo no generó contenido de resumen.")

    return summary, key_points


# ---------------------------------------------------------------------------
# Funcionalidad 2: Mapa mental
# ---------------------------------------------------------------------------
def generate_mindmap(transcript_text: str, language: str, video_title: str) -> dict:
    provider = get_ai_provider()
    transcript_text = _truncate(transcript_text, settings.MAX_TRANSCRIPT_CHARS)

    system_prompt = (
        "Eres un asistente que convierte transcripciones de video en mapas mentales "
        "jerárquicos, claros y bien organizados. Identificas el tema central y los "
        "sub-temas/ideas de apoyo, sin inventar información que no esté en el texto."
    )

    user_prompt = f"""Idioma de salida obligatorio: {language}

Título del video (referencia, puede usarse o reformularse como nodo raíz): "{video_title}"

Genera un mapa mental jerárquico de la transcripción con un máximo de 3 niveles de profundidad,
máximo 6 ramas por nodo, y nodos con frases cortas (máximo 8 palabras).

Responde ÚNICAMENTE con un JSON válido (sin texto adicional, sin markdown) con esta forma exacta,
recursiva:
{{"title": "Tema central", "children": [{{"title": "Subtema 1", "children": [{{"title": "Detalle", "children": []}}]}}]}}

Transcripción del video:
\"\"\"
{transcript_text}
\"\"\"
"""

    raw = provider.generate(system_prompt, user_prompt, max_tokens=1800)
    data = _safe_json_parse(raw)

    if "title" not in data:
        raise AIProviderError("El modelo no generó una estructura de mapa mental válida.")

    return data


# ---------------------------------------------------------------------------
# Funcionalidad 3: Chat / Preguntas y respuestas (RAG simple)
# ---------------------------------------------------------------------------
def answer_question_with_context(
    question: str, context_chunks: List[str], language: str
) -> str:
    provider = get_ai_provider()

    numbered_context = "\n\n".join(
        f"[Fragmento {i+1}]\n{chunk}" for i, chunk in enumerate(context_chunks)
    )

    system_prompt = (
        "Eres un asistente que responde preguntas sobre el contenido de un video de YouTube, "
        "basándote ÚNICAMENTE en los fragmentos de transcripción proporcionados. "
        "Si la respuesta no está en los fragmentos, dilo honestamente en vez de inventar."
    )

    user_prompt = f"""Idioma de salida obligatorio: {language}

Fragmentos relevantes de la transcripción del video:
{numbered_context if numbered_context else "(no se encontraron fragmentos relevantes)"}

Pregunta del usuario: {question}

Responde de forma directa y concisa (máximo 150 palabras), citando si es útil a qué parte del
contenido te refieres. No uses formato JSON, responde en texto plano.
"""

    answer = provider.generate(system_prompt, user_prompt, max_tokens=600)
    return answer.strip()
