"""
Servicio de recuperación (retrieval) ligero para la funcionalidad de chat/QA.

En vez de depender de embeddings + FAISS (más pesado de instalar y de
mantener para un proyecto de este tamaño), usamos TF-IDF + similitud de
coseno con scikit-learn. Es suficientemente bueno para encontrar, dentro de
los fragmentos de la transcripción de UN solo video, cuáles son los más
relevantes para responder una pregunta concreta.

Si en el futuro se quiere escalar a búsqueda semántica más sofisticada
(embeddings + FAISS/Pinecone), esta función es el único punto a sustituir.
"""
from __future__ import annotations

from typing import List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.config import get_settings

settings = get_settings()


def retrieve_relevant_chunks(chunks: List[str], question: str, top_k: int | None = None) -> List[str]:
    """Devuelve los `top_k` fragmentos más relevantes para `question`, ordenados por relevancia."""
    top_k = top_k or settings.CHAT_TOP_K_CHUNKS

    if not chunks:
        return []
    if len(chunks) <= top_k:
        return chunks

    vectorizer = TfidfVectorizer(stop_words=None, max_features=5000)
    try:
        chunk_vectors = vectorizer.fit_transform(chunks)
        question_vector = vectorizer.transform([question])
    except ValueError:
        # Vocabulario vacío (texto muy corto/raro): devolvemos los primeros fragmentos
        return chunks[:top_k]

    similarities = cosine_similarity(question_vector, chunk_vectors)[0]
    ranked_indices = similarities.argsort()[::-1][:top_k]
    # Mantenemos el orden original del video para que el contexto sea más legible
    ranked_indices_sorted = sorted(ranked_indices)
    return [chunks[i] for i in ranked_indices_sorted]
