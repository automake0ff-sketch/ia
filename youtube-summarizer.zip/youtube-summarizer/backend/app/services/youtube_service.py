"""
Servicio responsable de toda la interacción con YouTube:
  - Parsear/validar URLs y extraer el video_id.
  - Obtener metadatos (título, miniatura, canal, duración) vía yt-dlp.
  - Obtener la transcripción (subtítulos) vía youtube-transcript-api, con
    fallback automático a subtítulos auto-generados o traducidos.
  - Caché en memoria con TTL para evitar golpear YouTube repetidamente
    durante una sesión de chat/mindmap/resumen sobre el mismo video.

Nota de producción: la caché en memoria es válida para una sola instancia/
proceso. Si se despliega con varios workers o réplicas, sustituir por Redis.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

import yt_dlp
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import (
    NoTranscriptFound,
    TranscriptsDisabled,
    VideoUnavailable as YTVideoUnavailable,
)

from app.config import get_settings
from app.exceptions import (
    InvalidYouTubeURLError,
    TranscriptNotAvailableError,
    VideoUnavailableError,
)

settings = get_settings()

_VIDEO_ID_RE = re.compile(r"^[\w-]{11}$")
# Fallback por si el parseo estructurado de la URL no encuentra nada (ej. URLs raras o copiadas a medias)
_YOUTUBE_ID_FALLBACK_PATTERNS = [
    re.compile(r"(?:[?&]v=)([\w-]{11})"),
    re.compile(r"(?:youtu\.be/)([\w-]{11})"),
    re.compile(r"(?:/(?:embed|shorts|v|live)/)([\w-]{11})"),
]


@dataclass
class VideoMetadata:
    video_id: str
    title: str
    channel: Optional[str]
    thumbnail: Optional[str]
    duration_seconds: Optional[int]


@dataclass
class TranscriptData:
    full_text: str
    segments: List[dict]
    language_code: str
    source: str  # "manual" | "auto_generated" | "translated"
    available_languages: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Caché en memoria simple con TTL
# ---------------------------------------------------------------------------
_metadata_cache: Dict[str, Tuple[float, VideoMetadata]] = {}
_transcript_cache: Dict[str, Tuple[float, TranscriptData]] = {}


def _cache_get(cache: dict, key: str):
    entry = cache.get(key)
    if not entry:
        return None
    timestamp, value = entry
    if time.time() - timestamp > settings.TRANSCRIPT_CACHE_TTL_SECONDS:
        cache.pop(key, None)
        return None
    return value


def _cache_set(cache: dict, key: str, value) -> None:
    cache[key] = (time.time(), value)


# ---------------------------------------------------------------------------
# Extracción de video_id
# ---------------------------------------------------------------------------
def extract_video_id(url: str) -> str:
    """Extrae el video_id de cualquier formato común de URL de YouTube.

    Soporta: youtube.com/watch?v=ID (con o sin otros parámetros antes/después de v=),
    youtu.be/ID, youtube.com/shorts/ID, /embed/ID, /v/ID, /live/ID, dominios m./music.,
    y también el caso en que el usuario pega directamente el ID de 11 caracteres.
    """
    cleaned = url.strip()

    if _VIDEO_ID_RE.fullmatch(cleaned):
        return cleaned

    parsed = urlparse(cleaned if "://" in cleaned else f"https://{cleaned}")
    host = (parsed.netloc or "").lower()
    path_segments = [seg for seg in parsed.path.split("/") if seg]

    if "youtu.be" in host and path_segments:
        candidate = path_segments[0]
        if _VIDEO_ID_RE.fullmatch(candidate):
            return candidate

    if "youtube.com" in host or "youtube-nocookie.com" in host:
        query_params = parse_qs(parsed.query)
        if "v" in query_params and query_params["v"]:
            candidate = query_params["v"][0]
            if _VIDEO_ID_RE.fullmatch(candidate):
                return candidate

        if len(path_segments) >= 2 and path_segments[0] in ("embed", "shorts", "v", "live"):
            candidate = path_segments[1]
            if _VIDEO_ID_RE.fullmatch(candidate):
                return candidate

    for pattern in _YOUTUBE_ID_FALLBACK_PATTERNS:
        match = pattern.search(cleaned)
        if match:
            return match.group(1)

    raise InvalidYouTubeURLError(
        "La URL no parece ser un enlace válido de YouTube. "
        "Ejemplos válidos: https://www.youtube.com/watch?v=XXXXXXXXXXX o https://youtu.be/XXXXXXXXXXX"
    )


# ---------------------------------------------------------------------------
# Metadatos (yt-dlp)
# ---------------------------------------------------------------------------
def get_video_metadata(video_id: str) -> VideoMetadata:
    cached = _cache_get(_metadata_cache, video_id)
    if cached:
        return cached

    url = f"https://www.youtube.com/watch?v={video_id}"
    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "extract_flat": False,
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
    except yt_dlp.utils.DownloadError as exc:
        raise VideoUnavailableError(
            f"No se pudo acceder al video. Puede ser privado, haber sido eliminado o "
            f"estar restringido geográficamente. Detalle: {exc}"
        ) from exc

    thumbnail = info.get("thumbnail")
    if not thumbnail and info.get("thumbnails"):
        thumbnail = info["thumbnails"][-1].get("url")

    metadata = VideoMetadata(
        video_id=video_id,
        title=info.get("title") or "Título no disponible",
        channel=info.get("channel") or info.get("uploader"),
        thumbnail=thumbnail,
        duration_seconds=info.get("duration"),
    )
    _cache_set(_metadata_cache, video_id, metadata)
    return metadata


# ---------------------------------------------------------------------------
# Transcripción (youtube-transcript-api)
# ---------------------------------------------------------------------------
def get_transcript(video_id: str, language: str = "es") -> TranscriptData:
    cache_key = f"{video_id}:{language}"
    cached = _cache_get(_transcript_cache, cache_key)
    if cached:
        return cached

    try:
        transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
    except (TranscriptsDisabled, NoTranscriptFound) as exc:
        raise TranscriptNotAvailableError(
            "Este video no tiene subtítulos/transcripción disponibles, por lo que no es "
            "posible generar un resumen. Prueba con otro video que tenga subtítulos activados."
        ) from exc
    except YTVideoUnavailable as exc:
        raise VideoUnavailableError("El video no está disponible.") from exc

    available_languages = [t.language_code for t in transcript_list]

    transcript_obj = None
    source = "manual"

    # 1) Intentar encontrar transcripción (manual o auto) exactamente en el idioma pedido
    try:
        transcript_obj = transcript_list.find_transcript([language])
        source = "auto_generated" if transcript_obj.is_generated else "manual"
    except NoTranscriptFound:
        pass

    # 2) Si no existe en ese idioma, tomar cualquiera disponible y traducirla
    if transcript_obj is None:
        base_transcript = None
        for t in transcript_list:
            base_transcript = t
            if not t.is_generated:
                break  # preferimos una transcripción manual como base de traducción

        if base_transcript is None:
            raise TranscriptNotAvailableError("No se encontró ninguna transcripción utilizable.")

        translatable_codes = [lang["language_code"] for lang in base_transcript.translation_languages] \
            if base_transcript.is_translatable else []

        if base_transcript.is_translatable and language in translatable_codes:
            transcript_obj = base_transcript.translate(language)
            source = "translated"
        else:
            # Último recurso: usar la transcripción base en su idioma original
            transcript_obj = base_transcript
            source = "auto_generated" if base_transcript.is_generated else "manual"
            language = base_transcript.language_code

    try:
        segments = transcript_obj.fetch()
    except Exception as exc:  # noqa: BLE001 - librería externa, mensaje genérico controlado
        raise TranscriptNotAvailableError(
            f"No se pudo descargar la transcripción del video: {exc}"
        ) from exc

    # En versiones recientes fetch() devuelve objetos FetchedTranscriptSnippet; normalizamos a dict
    normalized_segments = [
        {
            "text": seg["text"] if isinstance(seg, dict) else seg.text,
            "start": seg["start"] if isinstance(seg, dict) else seg.start,
            "duration": seg["duration"] if isinstance(seg, dict) else seg.duration,
        }
        for seg in segments
    ]
    full_text = " ".join(s["text"].strip() for s in normalized_segments if s["text"].strip())

    data = TranscriptData(
        full_text=full_text,
        segments=normalized_segments,
        language_code=language,
        source=source,
        available_languages=available_languages,
    )
    _cache_set(_transcript_cache, cache_key, data)
    return data


# ---------------------------------------------------------------------------
# Utilidades de chunking (usadas por mindmap y chat/QA)
# ---------------------------------------------------------------------------
def chunk_text(text: str, chunk_size_words: Optional[int] = None) -> List[str]:
    """Divide el texto en fragmentos de N palabras (sin cortar en seco frases largas)."""
    chunk_size_words = chunk_size_words or settings.CHUNK_SIZE_WORDS
    words = text.split()
    if not words:
        return []
    chunks = []
    for i in range(0, len(words), chunk_size_words):
        chunk = " ".join(words[i : i + chunk_size_words])
        if chunk.strip():
            chunks.append(chunk.strip())
    return chunks
