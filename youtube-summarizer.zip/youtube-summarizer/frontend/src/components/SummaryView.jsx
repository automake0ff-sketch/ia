function renderSummaryBody(summary, format) {
  if (format === "bullets") {
    const lines = summary
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .map((l) => l.replace(/^[-•]\s*/, ""));

    if (lines.length > 1) {
      return (
        <ul className="space-y-2.5">
          {lines.map((line, i) => (
            <li key={i} className="flex gap-2.5 text-ink leading-relaxed">
              <span className="mt-2 h-1.5 w-1.5 rounded-full bg-accent shrink-0" />
              <span>{line}</span>
            </li>
          ))}
        </ul>
      );
    }
  }

  return summary
    .split(/\n\s*\n/)
    .filter(Boolean)
    .map((para, i) => (
      <p key={i} className="text-ink leading-relaxed mb-3 last:mb-0">
        {para.trim()}
      </p>
    ));
}

export default function SummaryView({ summary, keyPoints, format }) {
  if (!summary) return null;

  return (
    <div className="rounded-lg bg-surface shadow-card border border-line p-5 sm:p-6">
      {keyPoints?.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-5">
          {keyPoints.map((point, i) => (
            <span
              key={i}
              className="text-xs font-mono px-2.5 py-1.5 rounded-sm bg-amber-light text-ink border border-amber/30"
            >
              {point}
            </span>
          ))}
        </div>
      )}
      <div className="scrubber-static mb-5" />
      {renderSummaryBody(summary, format)}
    </div>
  );
}
