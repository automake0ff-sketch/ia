function formatDuration(seconds) {
  if (!seconds) return null;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const pad = (n) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

const SOURCE_LABEL = {
  manual: "Subtítulos originales",
  auto_generated: "Subtítulos automáticos",
  translated: "Transcripción traducida",
};

export default function VideoCard({ video, transcriptSource }) {
  if (!video) return null;

  return (
    <div className="rounded-lg bg-surface shadow-card border border-line p-4 flex gap-4 items-start">
      {video.thumbnail ? (
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-40 sm:w-48 aspect-video object-cover rounded-md border border-line shrink-0"
        />
      ) : (
        <div className="w-40 sm:w-48 aspect-video rounded-md border border-line bg-mist shrink-0" />
      )}

      <div className="flex flex-col gap-1.5 min-w-0">
        <h2 className="font-display font-semibold text-lg text-ink leading-snug line-clamp-2">
          {video.title}
        </h2>
        <p className="text-sm text-muted">{video.channel}</p>

        <div className="flex flex-wrap items-center gap-2 mt-1">
          {video.duration_seconds ? (
            <span className="font-mono text-xs px-2 py-1 rounded-sm bg-mist text-ink border border-line">
              {formatDuration(video.duration_seconds)}
            </span>
          ) : null}
          {transcriptSource ? (
            <span className="font-mono text-xs px-2 py-1 rounded-sm bg-accent-light text-accent-dark border border-accent/30">
              {SOURCE_LABEL[transcriptSource] || transcriptSource}
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
}
