export default function Loader({ label }) {
  return (
    <div className="flex flex-col gap-3 py-6" role="status" aria-live="polite">
      <div className="scrubber-track">
        <div className="scrubber-fill" />
      </div>
      <p className="text-sm text-muted font-mono">{label}</p>
    </div>
  );
}
