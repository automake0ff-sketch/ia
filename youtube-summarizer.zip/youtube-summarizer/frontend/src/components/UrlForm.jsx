import LanguageSelector from "./LanguageSelector.jsx";

const FORMAT_OPTIONS = [
  { value: "bullets", label: "Viñetas" },
  { value: "paragraph", label: "Párrafo" },
];

const LENGTH_OPTIONS = [
  { value: "short", label: "Corto" },
  { value: "medium", label: "Medio" },
  { value: "long", label: "Largo" },
];

export default function UrlForm({
  url,
  setUrl,
  language,
  setLanguage,
  format,
  setFormat,
  length,
  setLength,
  languages,
  onSubmit,
  loading,
}) {
  function handleSubmit(e) {
    e.preventDefault();
    if (!url.trim() || loading) return;
    onSubmit();
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-lg bg-surface shadow-card border border-line p-5 sm:p-6">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1 flex items-center gap-2 rounded-md border border-line bg-mist px-4 py-3 focus-within:border-accent focus-within:ring-1 focus-within:ring-accent">
          <span className="font-mono text-xs text-muted shrink-0">URL ▸</span>
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://www.youtube.com/watch?v=..."
            className="w-full bg-transparent outline-none text-sm text-ink placeholder:text-muted/70"
            autoComplete="off"
            spellCheck={false}
          />
        </div>
        <button
          type="submit"
          disabled={loading || !url.trim()}
          className="shrink-0 rounded-md bg-ink px-6 py-3 text-sm font-semibold text-white
                     hover:bg-accent-dark transition-colors disabled:opacity-40 disabled:hover:bg-ink"
        >
          {loading ? "Procesando…" : "Resumir video"}
        </button>
      </div>

      <div className="mt-4 flex flex-wrap items-end gap-4">
        <LanguageSelector value={language} onChange={setLanguage} languages={languages} disabled={loading} />

        <fieldset className="flex flex-col gap-1.5 text-sm" disabled={loading}>
          <span className="font-medium text-ink">Formato</span>
          <div className="flex rounded-md border border-line overflow-hidden">
            {FORMAT_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setFormat(opt.value)}
                className={`px-3 py-2 text-sm font-mono transition-colors ${
                  format === opt.value ? "bg-accent text-white" : "bg-surface text-ink hover:bg-mist"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset className="flex flex-col gap-1.5 text-sm" disabled={loading}>
          <span className="font-medium text-ink">Detalle</span>
          <div className="flex rounded-md border border-line overflow-hidden">
            {LENGTH_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setLength(opt.value)}
                className={`px-3 py-2 text-sm font-mono transition-colors ${
                  length === opt.value ? "bg-accent text-white" : "bg-surface text-ink hover:bg-mist"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </fieldset>
      </div>
    </form>
  );
}
