const DEPTH_STYLES = [
  { dot: "bg-ink", text: "text-ink font-display font-semibold text-lg" },
  { dot: "bg-accent", text: "text-ink font-medium text-base" },
  { dot: "bg-amber", text: "text-muted text-sm" },
];

function styleForDepth(depth) {
  return DEPTH_STYLES[Math.min(depth, DEPTH_STYLES.length - 1)];
}

function MindMapNode({ node, depth }) {
  const style = styleForDepth(depth);
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div className={depth > 0 ? "border-l border-line pl-4 ml-1.5" : ""}>
      <div className="flex items-center gap-2.5 py-1.5">
        <span className={`h-2 w-2 rounded-full shrink-0 ${style.dot}`} />
        <span className={style.text}>{node.title}</span>
      </div>
      {hasChildren && (
        <div className="space-y-0.5">
          {node.children.map((child, i) => (
            <MindMapNode key={i} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function MindMapView({ mindmap }) {
  if (!mindmap) return null;

  return (
    <div className="rounded-lg bg-surface shadow-card border border-line p-5 sm:p-6 overflow-x-auto">
      <MindMapNode node={mindmap} depth={0} />
    </div>
  );
}
