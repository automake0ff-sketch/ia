import { useState } from "react";
import Loader from "./Loader.jsx";

export default function ChatPanel({ messages, onSend, loading, disabled }) {
  const [question, setQuestion] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!question.trim() || loading) return;
    onSend(question.trim());
    setQuestion("");
  }

  return (
    <div className="rounded-lg bg-surface shadow-card border border-line flex flex-col h-[520px]">
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {messages.length === 0 && (
          <p className="text-sm text-muted">
            Pregunta lo que quieras sobre el contenido del video. Por ejemplo: "¿qué herramientas
            menciona?" o "resume la parte final".
          </p>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-md px-4 py-2.5 text-sm leading-relaxed ${
                msg.role === "user"
                  ? "bg-ink text-white"
                  : msg.role === "error"
                  ? "bg-danger/10 text-danger border border-danger/30"
                  : "bg-mist text-ink border border-line"
              }`}
            >
              <p>{msg.content}</p>
              {msg.usedContext?.length > 0 && (
                <details className="mt-2">
                  <summary className="text-xs font-mono text-muted cursor-pointer">
                    Fragmentos usados ({msg.usedContext.length})
                  </summary>
                  <div className="mt-1.5 space-y-1.5">
                    {msg.usedContext.map((chunk, j) => (
                      <p key={j} className="text-xs text-muted border-l-2 border-line pl-2">
                        {chunk.slice(0, 220)}
                        {chunk.length > 220 ? "…" : ""}
                      </p>
                    ))}
                  </div>
                </details>
              )}
            </div>
          </div>
        ))}

        {loading && <Loader label="Buscando en la transcripción…" />}
      </div>

      <form onSubmit={handleSubmit} className="border-t border-line p-3 flex gap-2">
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          disabled={disabled || loading}
          placeholder={disabled ? "Resume un video primero…" : "Escribe tu pregunta…"}
          className="flex-1 rounded-md border border-line bg-mist px-3 py-2 text-sm outline-none
                     focus:border-accent focus:ring-1 focus:ring-accent disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={disabled || loading || !question.trim()}
          className="rounded-md bg-ink px-4 py-2 text-sm font-semibold text-white hover:bg-accent-dark
                     transition-colors disabled:opacity-40 disabled:hover:bg-ink"
        >
          Enviar
        </button>
      </form>
    </div>
  );
}
