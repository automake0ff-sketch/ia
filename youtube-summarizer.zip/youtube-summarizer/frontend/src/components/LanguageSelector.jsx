export default function LanguageSelector({ value, onChange, languages, disabled, label = "Idioma del resumen" }) {
  return (
    <label className="flex flex-col gap-1.5 text-sm">
      <span className="font-medium text-ink">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className="rounded-md border border-line bg-surface px-3 py-2 text-sm font-mono text-ink
                   focus:border-accent focus:ring-1 focus:ring-accent disabled:opacity-50"
      >
        {languages.map((lang) => (
          <option key={lang.code} value={lang.code}>
            {lang.label} ({lang.code})
          </option>
        ))}
      </select>
    </label>
  );
}
