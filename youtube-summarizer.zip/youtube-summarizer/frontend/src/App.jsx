import { useEffect, useState } from "react";
import api from "./api/client.js";
import UrlForm from "./components/UrlForm.jsx";
import VideoCard from "./components/VideoCard.jsx";
import SummaryView from "./components/SummaryView.jsx";
import MindMapView from "./components/MindMapView.jsx";
import ChatPanel from "./components/ChatPanel.jsx";
import Loader from "./components/Loader.jsx";

const FALLBACK_LANGUAGES = [
  { code: "es", label: "Español" },
  { code: "en", label: "English" },
  { code: "pt", label: "Português" },
  { code: "fr", label: "Français" },
];

const TABS = [
  { id: "summary", label: "Resumen" },
  { id: "mindmap", label: "Mapa mental" },
  { id: "chat", label: "Chat" },
];

export default function App() {
  const [languages, setLanguages] = useState(FALLBACK_LANGUAGES);

  // Formulario
  const [url, setUrl] = useState("");
  const [language, setLanguage] = useState("es");
  const [format, setFormat] = useState("bullets");
  const [length, setLength] = useState("medium");

  // Resultado del resumen
  const [video, setVideo] = useState(null);
  const [summary, setSummary] = useState(null);
  const [keyPoints, setKeyPoints] = useState([]);
  const [transcriptSource, setTranscriptSource] = useState(null);

  // Mapa mental (carga perezosa, solo al abrir la pestaña)
  const [mindmap, setMindmap] = useState(null);
  const [mindmapLoading, setMindmapLoading] = useState(false);

  // Chat
  const [chatMessages, setChatMessages] = useState([]);
  const [chatLoading, setChatLoading] = useState(false);

  const [activeTab, setActiveTab] = useState("summary");
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [error, setError] = useState(null);
  const [submittedUrl, setSubmittedUrl] = useState("");

  useEffect(() => {
    api
      .getLanguages()
      .then((data) => setLanguages(data))
      .catch(() => {
        /* si falla, nos quedamos con FALLBACK_LANGUAGES */
      });
  }, []);

  async function handleSummarize() {
    setError(null);
    setLoadingSummary(true);
    setMindmap(null);
    setChatMessages([]);
    setActiveTab("summary");

    try {
      const data = await api.summarize({ url, language, format, length });
      setVideo(data.video);
      setSummary(data.summary);
      setKeyPoints(data.key_points);
      setTranscriptSource(data.transcript_source);
      setSubmittedUrl(url);
    } catch (err) {
      setError(err.message);
      setVideo(null);
      setSummary(null);
    } finally {
      setLoadingSummary(false);
    }
  }

  async function handleOpenMindmap() {
    setActiveTab("mindmap");
    if (mindmap || mindmapLoading || !submittedUrl) return;

    setMindmapLoading(true);
    setError(null);
    try {
      const data = await api.mindmap(submittedUrl, language);
      setMindmap(data.mindmap);
    } catch (err) {
      setError(err.message);
    } finally {
      setMindmapLoading(false);
    }
  }

  async function handleSendChat(question) {
    setChatMessages((prev) => [...prev, { role: "user", content: question }]);
    setChatLoading(true);
    try {
      const data = await api.chat({ url: submittedUrl, language, question });
      setChatMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.answer, usedContext: data.used_context },
      ]);
    } catch (err) {
      setChatMessages((prev) => [...prev, { role: "error", content: err.message }]);
    } finally {
      setChatLoading(false);
    }
  }

  const hasResult = Boolean(video && summary);

  return (
    <div className="min-h-screen bg-mist">
      <header className="border-b border-line bg-surface">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center gap-2.5">
            <svg viewBox="0 0 32 32" className="h-8 w-8 shrink-0">
              <rect width="32" height="32" rx="8" fill="#14181F" />
              <path d="M12 9.5L23 16L12 22.5V9.5Z" fill="#00B8A0" />
              <circle cx="23.5" cy="23.5" r="2.5" fill="#FFB100" />
            </svg>
            <div>
              <h1 className="font-display font-bold text-xl text-ink leading-none">
                Resumidor de YouTube
              </h1>
              <p className="text-xs text-muted font-mono mt-1">resumen · mapa mental · chat con IA</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <UrlForm
          url={url}
          setUrl={setUrl}
          language={language}
          setLanguage={setLanguage}
          format={format}
          setFormat={setFormat}
          length={length}
          setLength={setLength}
          languages={languages}
          onSubmit={handleSummarize}
          loading={loadingSummary}
        />

        {error && (
          <div className="rounded-md bg-danger/10 border border-danger/30 text-danger text-sm px-4 py-3 flex justify-between items-start gap-3">
            <span>{error}</span>
            <button onClick={() => setError(null)} className="font-mono text-xs shrink-0">
              cerrar ✕
            </button>
          </div>
        )}

        {loadingSummary && <Loader label="Extrayendo transcripción y generando resumen…" />}

        {hasResult && !loadingSummary && (
          <>
            <VideoCard video={video} transcriptSource={transcriptSource} />

            <div className="flex gap-1 border-b border-line">
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => (tab.id === "mindmap" ? handleOpenMindmap() : setActiveTab(tab.id))}
                  className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? "border-accent text-ink"
                      : "border-transparent text-muted hover:text-ink"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {activeTab === "summary" && (
              <SummaryView summary={summary} keyPoints={keyPoints} format={format} />
            )}

            {activeTab === "mindmap" && (
              <>
                {mindmapLoading && <Loader label="Construyendo el mapa mental…" />}
                {!mindmapLoading && mindmap && <MindMapView mindmap={mindmap} />}
              </>
            )}

            {activeTab === "chat" && (
              <ChatPanel
                messages={chatMessages}
                onSend={handleSendChat}
                loading={chatLoading}
                disabled={!submittedUrl}
              />
            )}
          </>
        )}

        {!hasResult && !loadingSummary && (
          <div className="text-center py-16">
            <p className="text-muted text-sm">
              Pega la URL de un video de YouTube arriba para empezar.
            </p>
          </div>
        )}
      </main>

      <footer className="max-w-4xl mx-auto px-4 sm:px-6 py-8 text-xs text-muted font-mono">
        Hecho con FastAPI + React · funciona con Gemini, OpenAI o Claude
      </footer>
    </div>
  );
}
