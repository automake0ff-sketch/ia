import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

const client = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60_000,
});

/**
 * Normaliza errores de axios/FastAPI en un mensaje legible para mostrar en la UI.
 */
function extractErrorMessage(error) {
  if (error.response?.data?.detail) {
    return error.response.data.detail;
  }
  if (error.code === "ECONNABORTED") {
    return "La solicitud tardó demasiado en responder. Intenta de nuevo.";
  }
  if (error.message === "Network Error") {
    return "No se pudo conectar con el servidor. ¿Está corriendo el backend en " + API_BASE_URL + "?";
  }
  return error.message || "Ocurrió un error inesperado.";
}

async function request(method, url, data) {
  try {
    const response = await client.request({ method, url, data });
    return response.data;
  } catch (error) {
    throw new Error(extractErrorMessage(error));
  }
}

export const api = {
  getVideoInfo: (url, language) => request("post", "/api/video/info", { url, language }),

  summarize: ({ url, language, format, length }) =>
    request("post", "/api/video/summarize", { url, language, format, length }),

  mindmap: (url, language) => request("post", "/api/video/mindmap", { url, language }),

  chat: ({ url, language, question }) =>
    request("post", "/api/video/chat", { url, language, question }),

  getLanguages: () => request("get", "/api/languages"),
};

export default api;
